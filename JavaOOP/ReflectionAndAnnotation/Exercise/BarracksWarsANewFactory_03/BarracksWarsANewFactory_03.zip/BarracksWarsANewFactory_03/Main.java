package BarracksWarsANewFactory_03;

import BarracksWarsANewFactory_03.interfaces.Repository;
import BarracksWarsANewFactory_03.interfaces.Runnable;
import BarracksWarsANewFactory_03.interfaces.UnitFactory;
import BarracksWarsANewFactory_03.core.Engine;
import BarracksWarsANewFactory_03.core.factories.UnitFactoryImpl;
import BarracksWarsANewFactory_03.data.UnitRepository;

public class Main {

    public static void main(String[] args) {
        Repository repository = new UnitRepository();
        UnitFactory unitFactory = new UnitFactoryImpl();

        Runnable engine = new Engine(repository, unitFactory);
        engine.run();
    }

    //Engine -> parse and execute commands
    //Repository -> военна единица : брой
        //archer: брой стрелци
        //pikeman: брой копиеносци
        //swordsman: брой мечоносците
    //UnitFactory: създаване на военни единици
}
