package BarracksWarsANewFactory_03.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
