package JavaOOP.ReflectionAndAnnotation.Lab.CreateAnnotation_04;

@Subject(categories = {"Test", "Annotation"})
public class TestClass {

}
