package WildFarm_04;

public abstract class Felime extends Mammal {

    protected Felime(String type, String name, double weight, String livingRegion) {
        super(type, name, weight, livingRegion);
    }
}
