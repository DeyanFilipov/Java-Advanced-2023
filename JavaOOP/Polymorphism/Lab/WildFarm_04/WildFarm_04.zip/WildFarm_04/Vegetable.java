package WildFarm_04;

public class Vegetable extends Food {

    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
