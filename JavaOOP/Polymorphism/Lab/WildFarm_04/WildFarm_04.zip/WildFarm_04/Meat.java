package WildFarm_04;

public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }
}
