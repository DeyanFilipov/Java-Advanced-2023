package Word_03;

public interface TextTransform {
    void invokeOn(StringBuilder text, int startIndex, int endIndex);
}
