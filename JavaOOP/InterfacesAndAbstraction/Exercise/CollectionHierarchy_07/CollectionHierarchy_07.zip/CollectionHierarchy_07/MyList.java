package CollectionHierarchy_07;

public interface MyList extends AddRemovable {

    int getUsed();
}
