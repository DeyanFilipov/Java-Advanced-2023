package BirthdayCelebrations_03;

public interface Birthable {

    String getBirthDate();
}
