package FoodShortage_04;

public interface Person {

    String getName();
    int getAge();
}
