package FoodShortage_04;

public interface Buyer extends Person {

    void buyFood();
    int getFood();
}
