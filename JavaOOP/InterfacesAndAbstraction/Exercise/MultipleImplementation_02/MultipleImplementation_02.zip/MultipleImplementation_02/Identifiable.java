package MultipleImplementation_02;

public interface Identifiable {

    String getId();
}
