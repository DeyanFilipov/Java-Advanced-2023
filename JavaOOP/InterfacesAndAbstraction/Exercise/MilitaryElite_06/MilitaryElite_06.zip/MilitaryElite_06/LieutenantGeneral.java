package MilitaryElite_06;

public interface LieutenantGeneral {

    void addPrivate(Private privateSoldier);

}
