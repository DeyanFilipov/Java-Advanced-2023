package MilitaryElite_06;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();

}
