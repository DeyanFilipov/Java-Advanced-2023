package MilitaryElite_06;

public interface SpecialisedSoldier {
    String getCorps();
}
