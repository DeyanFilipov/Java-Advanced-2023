package MilitaryElite_06;

public interface Mission {
    void completeMission();

    String getCodeName();

    String getState();
}
