package MilitaryElite_06;

public interface Private extends Soldier{
    double getSalary();
}
