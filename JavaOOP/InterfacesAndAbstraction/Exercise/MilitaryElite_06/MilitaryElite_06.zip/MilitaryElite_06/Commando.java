package MilitaryElite_06;

import java.util.List;

public interface Commando {
    void addMission(Mission mission);
    List<Mission> getMissions();
}
