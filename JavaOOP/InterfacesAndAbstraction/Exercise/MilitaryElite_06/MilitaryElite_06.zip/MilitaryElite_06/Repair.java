package MilitaryElite_06;

public interface Repair {
    String getName();
    int getHoursWorked();
}
