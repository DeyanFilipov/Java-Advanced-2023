package SayHelloExtended_04;

public interface Person {

    String getName();
    String sayHello();
}
