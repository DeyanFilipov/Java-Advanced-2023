package CarShopExtended_02;

public interface Sellable {

    Double getPrice();
}
