package Restaurant_05;

public class Main {
}
